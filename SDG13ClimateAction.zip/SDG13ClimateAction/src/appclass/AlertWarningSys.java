
package appclass;
import java.util.ArrayList;
import java.util.Scanner;

public class AlertWarningSys {
    private final Scanner scanner = new Scanner(System.in);
    private final ArrayList<WeatherAlert> alerts = new ArrayList<>();

    // Constructor to add some initial weather alerts for Malaysia
    public AlertWarningSys() {
        addWeatherAlert("Kuala Lumpur", 32.5, true, false);  // Hot and rainy
        addWeatherAlert("Penang", 28.0, false, true);      // Mild and stormy
        addWeatherAlert("Johor Bahru", 30.0, true, false); // Warm and rainy
        addWeatherAlert("Kota Kinabalu", 35.0, true, true); // Hot, rainy, and stormy
        addWeatherAlert("Kuching", 29.5, false, true);    // Mild and stormy
        addWeatherAlert("Langkawi", 27.0, false, false);  // Mild and clear
        addWeatherAlert("Melaka", 33.0, true, false);     // Warm and rainy
        addWeatherAlert("Ipoh", 34.0, false, true);       // Hot and stormy
        addWeatherAlert("Shah Alam", 31.0, false, false); // Warm and clear
        addWeatherAlert("Seremban", 28.5, true, false);   // Warm and rainy
        addWeatherAlert("Alor Setar", 30.0, true, false); // Warm and rainy
        addWeatherAlert("Putrajaya", 33.5, false, true);  // Hot and stormy
    }

    // WeatherAlert class nested inside AlertSystem
    public static class WeatherAlert {
        private String region;
        private double temperature;
        private boolean isRainy;
        private boolean isStormy;

        // Constructor
        public WeatherAlert(String region, double temperature, boolean isRainy, boolean isStormy) {
            this.region = region;
            this.temperature = temperature;
            this.isRainy = isRainy;
            this.isStormy = isStormy;
        }

        // Getters and setters
        public String getRegion() {
            return region;
        }

        public double getTemperature() {
            return temperature;
        }

        public boolean isRainy() {
            return isRainy;
        }

        public boolean isStormy() {
            return isStormy;
        }

        public void setTemperature(double temperature) {
            this.temperature = temperature;
        }

        public void setRainy(boolean rainy) {
            isRainy = rainy;
        }

        public void setStormy(boolean stormy) {
            isStormy = stormy;
        }

        public String getAlertInfo() {
            return "Region: " + region + "\nTemperature: " + temperature + "°C" +
                    "\nRainy: " + (isRainy ? "Yes" : "No") +
                    "\nStormy: " + (isStormy ? "Yes" : "No");
        }
    }

    // Method for public user tasks
    public void publicUserTasks() {
        int choice;
        do {
            System.out.println("\n--- Public User Menu ---");
            System.out.println("1. View all weather alerts");
            System.out.println("2. Search weather alerts by region");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear invalid input
            }
            choice = scanner.nextInt();
            scanner.nextLine(); // Clear newline

            switch (choice) {
                case 1:
                    viewAllAlerts();
                    break;
                case 2:
                    searchAlertByRegion();
                    break;
                case 0:
                    System.out.println("Exiting Public User Menu...");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 0);
    }

    // Method for admin user tasks
    public void adminUserTasks() {
        int choice;
        do {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. View all weather alerts");
            System.out.println("2. Update weather alert");
            System.out.println("3. Delete weather alert");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear invalid input
            }
            choice = scanner.nextInt();
            scanner.nextLine(); // Clear newline

            switch (choice) {
                case 1:
                    viewAllAlerts();
                    break;
                case 2:
                    updateAlert();
                    break;
                case 3:
                    deleteAlert();
                    break;
                case 0:
                    System.out.println("Exiting Admin Menu...");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 0);
    }

    // View all weather alerts
    private void viewAllAlerts() {
        if (alerts.isEmpty()) {
            System.out.println("No weather alerts available.");
        } else {
            System.out.println("\n--- Weather Alerts ---");
            for (WeatherAlert alert : alerts) {
                System.out.println(alert.getAlertInfo());
            }
        }
    }

    // Search weather alert by region
    private void searchAlertByRegion() {
        System.out.print("Enter the region to search for weather alerts: ");
        String region = scanner.nextLine().toLowerCase();

        boolean found = false;  // Track if any alert is found
        for (WeatherAlert alert : alerts) {
            if (alert.getRegion().toLowerCase().contains(region)) {
                System.out.println(alert.getAlertInfo());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No weather alert found for the specified region.");
        }
    }

    // Update weather alert
    private void updateAlert() {
        System.out.print("Enter the region to update the weather alert: ");
        String region = scanner.nextLine().toLowerCase();

        boolean alertFound = false;  // To track if the alert is found
        for (WeatherAlert alert : alerts) {
            if (alert.getRegion().toLowerCase().contains(region)) {
                alertFound = true;
                System.out.print("Enter new temperature: ");
                while (!scanner.hasNextDouble()) {
                    System.out.println("Invalid input. Please enter a valid temperature.");
                    scanner.next();
                }
                double newTemp = scanner.nextDouble();

                System.out.print("Is it rainy? (true/false): ");
                while (!scanner.hasNextBoolean()) {
                    System.out.println("Invalid input. Please enter true or false.");
                    scanner.next();
                }
                boolean isRainy = scanner.nextBoolean();

                System.out.print("Is there a storm warning? (true/false): ");
                while (!scanner.hasNextBoolean()) {
                    System.out.println("Invalid input. Please enter true or false.");
                    scanner.next();
                }
                boolean isStormy = scanner.nextBoolean();

                alert.setTemperature(newTemp);
                alert.setRainy(isRainy);
                alert.setStormy(isStormy);
                System.out.println("Weather alert successfully updated!");
                break;
            }
        }
        if (!alertFound) {
            System.out.println("No weather alert found for the specified region.");
        }
    }

    // Delete weather alert
    private void deleteAlert() {
        System.out.print("Enter the region to delete the weather alert: ");
        String region = scanner.nextLine().toLowerCase();

        boolean alertFound = false;  // To track if the alert is found
        for (int i = 0; i < alerts.size(); i++) {
            if (alerts.get(i).getRegion().toLowerCase().contains(region)) {
                alerts.remove(i);
                alertFound = true;
                System.out.println("Weather alert successfully deleted!");
                break;
            }
        }
        if (!alertFound) {
            System.out.println("No weather alert found for the specified region.");
        }
    }

    // Method to add a new weather alert
    private void addWeatherAlert(String region, double temperature, boolean isRainy, boolean isStormy) {
        WeatherAlert alert = new WeatherAlert(region, temperature, isRainy, isStormy);
        alerts.add(alert);
    }

   
}

