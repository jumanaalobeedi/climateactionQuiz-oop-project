
package appclass;

import java.util.Scanner;


public class CarbonFootprintCalculator {
    static double Electricity(double Elect){
        double Emission = Elect * 0.6;
        return Emission;
    }
    
    static double NaturalGas(double GasUsage){
        double Emission = GasUsage * 0.053;
        return Emission;
    }
    
    static double HeatingOil(double OilUsage){
        double Emission = OilUsage * 2.5;
        return Emission;
    }
    
    static double Flight(double flight){
        double Emission = flight * 0.12;
        return Emission;
    }
    
    static double Vehicle(double VDist){
        double Emission = VDist * 0.18;
        return Emission;
    }
    
    static double PublicTrans(double Traveldist){
        double Emission = Traveldist * 2.0;
        return Emission;
    }
    
    public static double getValidInput(Scanner sc, String prompt) {
        double value = 0;
        boolean valid = false;
        while (!valid) {
            System.out.println(prompt);
            if (sc.hasNextDouble()) {
                value = sc.nextDouble();
                valid = true; // If input is a valid number, exit the loop
            } else {
                System.out.println("Invalid input! Please enter a valid number.");
                sc.next(); // Consume the invalid input
            }
        }
        return value;
    }
        public void displayCalc(){

        Scanner sc = new Scanner(System.in);
        
        System.out.println("Welcome to the CO2 Calculator!");
        System.out.println("I'll help you estimate your carbon footprint based on your activities. Please enter the following values:");
        System.out.println();

        double Elect = getValidInput(sc, "ELECTRICITY USAGE\nHow much electricity do you use per month (in kWh)?");
        double GasUsage = getValidInput(sc, "NATURAL GAS USAGE\nHow much natural gas do you use per month (in cubic feet, cf)?");
        double OilUsage = getValidInput(sc, "HEATING OIL USAGE\nHow much heating oil do you use per month (in litres)?");
        double flight = getValidInput(sc, "FLIGHT DISTANCE\nHow many kilometers do you fly per month?");
        double VDist = getValidInput(sc, "VEHICLE MILEAGE\nHow far do you travel by car per month (in km)?");
        double PTdist = getValidInput(sc, "PUBLIC TRANSPORT USAGE\nHow much distance did you travel by bus or by train per month (in km)?");

        double totalCO2 = Electricity(Elect) + NaturalGas(GasUsage) + HeatingOil(OilUsage) + Flight(flight) + Vehicle(VDist) + PublicTrans(PTdist);
        
        // Round the result to two decimal places
        System.out.printf("\nTOTAL CO2 EMISSIONS: %.2f kg CO2e\n", totalCO2);
}
}