/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appclass;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author AYMAN FOKEERBUX
 */


/**
 *
 * @author AYMAN FOKEERBUX
 */
public class ClimateAwarenessBlog {

    // Subclass to handle blog management
    public static class BlogManager {
        private ArrayList<BlogPost> blogPosts;

        // Constructor
        public BlogManager() {
            this.blogPosts = new ArrayList<>();
            loadBlogPosts();
        }

        // Inner class to represent a blog post
        public class BlogPost {
            String title;
            String content;

            BlogPost(String title, String content) {
                this.title = title;
                this.content = content;
            }

            @Override
            public String toString() {
                return "Title: " + title + "\nContent:\n" + content + "\n";
            }
        }

        // Load hardcoded blog posts
        public void loadBlogPosts() {
            blogPosts.add(new BlogPost(
                "Easy Ways to Lower Your Carbon Footprint",
                "Fighting climate change requires lowering your carbon footprint. Here are some practical suggestions:\n" +
                "- Switch to energy-efficient appliances.\n" +
                "- Walk, cycle, or take public transport whenever possible.\n" +
                "- Choose a plant-based diet and reduce food waste."
            ));
            blogPosts.add(new BlogPost(
                "The Impact of Deforestation",
                "Deforestation has devastating effects on biodiversity and climate. Preserve forests by:\n" +
                "- Supporting reforestation projects.\n" +
                "- Using sustainable wood products.\n" +
                "- Raising awareness about deforestation's consequences."
            ));
            blogPosts.add(new BlogPost(
                "Plastic Pollution's Effects on the Environment",
                "Every year, millions of tons of plastic pollute the oceans, harming marine life. To reduce plastic pollution:\n" +
                "- Use reusable items like bottles and straws.\n" +
                "- Avoid single-use plastics.\n" +
                "- Participate in community cleanups."
            ));
        }

        // Admin functionality: Handle admin tasks
        public void handleAdmin(Scanner scanner) {
            boolean backToMain = false;

            while (!backToMain) {
                System.out.println("\n--- Admin Menu ---");
                System.out.println("1. View All Blog Posts");
                System.out.println("2. Delete a Blog Post");
                System.out.println("3. Edit a Blog Post");
                System.out.println("4. Search Blog Posts");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int adminChoice = scanner.nextInt();
                scanner.nextLine(); // Consume newline character

                switch (adminChoice) {
                    case 1:
                        viewAllPosts();
                        break;
                    case 2:
                        deletePost(scanner);
                        break;
                    case 3:
                        editPost(scanner);
                        break;
                    case 4:
                        searchPosts(scanner);
                        break;
                    case 5:
                        backToMain = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }

        // User functionality: Handle user tasks
        public void handleUser() {
            System.out.println("\n--- Public User Menu ---");
            if (blogPosts.isEmpty()) {
                System.out.println("No blog posts available.");
            } else {
                viewAllPosts();
            }
        }

        private void viewAllPosts() {
            if (blogPosts.isEmpty()) {
                System.out.println("No blog posts available.");
            } else {
                System.out.println("\n--- Blog Posts ---");
                for (BlogPost post : blogPosts) {
                    System.out.println(post);
                }
            }
        }

        private void deletePost(Scanner scanner) {
            if (blogPosts.isEmpty()) {
                System.out.println("No blog posts available to delete.");
                return;
            }

            System.out.println("\n--- Delete Blog Post ---");
            for (int i = 0; i < blogPosts.size(); i++) {
                System.out.println((i + 1) + ". " + blogPosts.get(i).title);
            }
            System.out.print("Enter the number of the blog post to delete: ");
            int deleteIndex = scanner.nextInt() - 1;
            scanner.nextLine(); // Consume newline character

            if (deleteIndex >= 0 && deleteIndex < blogPosts.size()) {
                System.out.println("Deleted blog post: " + blogPosts.get(deleteIndex).title);
                blogPosts.remove(deleteIndex);
            } else {
                System.out.println("Invalid selection. Please try again.");
            }
        }

        private void editPost(Scanner scanner) {
            if (blogPosts.isEmpty()) {
                System.out.println("No blog posts available to edit.");
                return;
            }

            System.out.println("\n--- Edit Blog Post ---");
            for (int i = 0; i < blogPosts.size(); i++) {
                System.out.println((i + 1) + ". " + blogPosts.get(i).title);
            }
            System.out.print("Enter the number of the blog post to edit: ");
            int editIndex = scanner.nextInt() - 1;
            scanner.nextLine(); // Consume newline character

            if (editIndex >= 0 && editIndex < blogPosts.size()) {
                BlogPost postToEdit = blogPosts.get(editIndex);
                System.out.println("\nEditing Blog Post: " + postToEdit.title);
                System.out.print("Enter new title (leave blank to keep current): ");
                String newTitle = scanner.nextLine();
                System.out.println("Enter new content (leave blank to keep current):");
                String newContent = scanner.nextLine();

                if (!newTitle.isBlank()) postToEdit.title = newTitle;
                if (!newContent.isBlank()) postToEdit.content = newContent;

                System.out.println("Blog post updated successfully!");
            } else {
                System.out.println("Invalid selection. Please try again.");
            }
        }

        public void searchPosts(Scanner scanner) {
            System.out.print("\nEnter a keyword to search for: ");
            String keyword = scanner.nextLine().toLowerCase();
            System.out.println("\n--- Search Results ---");
            boolean found = false;
            for (BlogPost post : blogPosts) {
                if (post.title.toLowerCase().contains(keyword) || post.content.toLowerCase().contains(keyword)) {
                    System.out.println(post);
                    found = true;
                }
            }
            if (!found) {
                System.out.println("No blog posts found with the keyword \"" + keyword + "\".");
           }
        }
     }
   }

