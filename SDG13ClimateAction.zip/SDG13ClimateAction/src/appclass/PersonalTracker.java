
package appclass;

import java.util.ArrayList;
import java.util.Scanner;


public class PersonalTracker {
    class Goal {
        private String description;
        private boolean isCompleted;

        public Goal(String description) {
            this.description = description;
            this.isCompleted = false;
        }

        public String getDescription() {
            return description;
        }

        public boolean isCompleted() {
            return isCompleted;
        }

        public void completeGoal() {
            isCompleted = true;
        }

        @Override
        public String toString() {
            return description + (isCompleted ? " (Completed)" : " (Not Completed)");
        }
    }

    public void Tracker() {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Goal> goals = new ArrayList<>();

        System.out.println("Welcome to the Goal Tracker!");
        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add a new goal");
            System.out.println("2. View all goals");
            System.out.println("3. Mark a goal as completed");
            System.out.println("4. Exit");

            int choice = getValidChoice(scanner);

            switch (choice) {
                case 1:
                    System.out.print("Enter your new goal: ");
                    String description = scanner.nextLine();
                    goals.add(new Goal(description));
                    System.out.println("Goal added successfully!");
                    break;
                case 2:
                    System.out.println("\nYour goals:");
                    if (goals.isEmpty()) {
                        System.out.println("No goals yet. Add one!");
                    } else {
                        for (int i = 0; i < goals.size(); i++) {
                            System.out.println((i + 1) + ". " + goals.get(i));
                        }
                    }
                    break;
                case 3:
                    if (goals.isEmpty()) {
                        System.out.println("No goals to mark as completed.");
                    } else {
                        System.out.println("\nSelect a goal to mark as completed:");
                        for (int i = 0; i < goals.size(); i++) {
                            System.out.println((i + 1) + ". " + goals.get(i));
                        }
                        int goalIndex = getValidGoalIndex(scanner, goals.size()) - 1;
                        goals.get(goalIndex).completeGoal();
                        System.out.println("Goal marked as completed!");
                    }
                    break;
                case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private int getValidChoice(Scanner scanner) {
        int choice;
        while (true) {
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= 4) {
                    break;
                } else {
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return choice;
    }

    private int getValidGoalIndex(Scanner scanner, int size) {
        int index;
        while (true) {
            try {
                index = Integer.parseInt(scanner.nextLine());
                if (index >= 1 && index <= size) {
                    break;
                } else {
                    System.out.println("Invalid selection. Please enter a number between 1 and " + size + ".");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return index;
    }
}

