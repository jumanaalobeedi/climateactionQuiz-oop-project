
package appclass;
import java.util.Scanner;
public class publicUser {
    Scanner sc = new Scanner(System.in);
    
    public void publicMenu(){

    Scanner sc = new Scanner(System.in); // Initialize Scanner
        // Public user menu
        int publicChoice = 0;
        do {
            System.out.println("Please choose one number from the following: \n" +
                               "1. Carbon Footprint Calculator. \n" +
                               "2. Interactive Climate Quiz. \n" +
                               "3. Climate Awareness Blog. \n" +
                               "4. Real-time Alert Warning System. \n" +
                               "5. Personal Tracker");

            // Validate input in the while loop
            while (!sc.hasNextInt() || (publicChoice = sc.nextInt()) < 1 || publicChoice > 5) {
                System.out.println("Invalid input! Please enter a number between 1 and 5.");
                sc.nextLine(); // Clear invalid input or newline
            }

            // Process the valid choice
            switch (publicChoice) {
                case 1:
                    // Carbon Footprint Calculator
                    CarbonFootprintCalculator carbonFCalc = new CarbonFootprintCalculator();
                    carbonFCalc.displayCalc();
                    break;
                case 2:
                    // Interactive Climate Quiz
                    InteractiveClimateQuiz icq = new InteractiveClimateQuiz();
                    icq.Quiz();
                    break;
                case 3:
                    // Climate Awareness Blog
                    ClimateAwarenessBlog.BlogManager nm = new ClimateAwarenessBlog.BlogManager();
                    nm.handleUser();

                    break;
                case 4:
                    // Real-time Alert Warning System
                    AlertWarningSys aWS = new AlertWarningSys();
                    aWS.publicUserTasks();
                    break;
                case 5:
                    // Personal Tracker
                    PersonalTracker pt = new PersonalTracker();
                    pt.Tracker();
                    break;
                default:
                    // This case won't occur due to validation
                    System.out.println("Unexpected error!");
                    break;
            }

            System.out.println("Do you want to return to the menu? (yes/no)");
            sc.nextLine(); // Consume the newline
        } while (sc.nextLine().equalsIgnoreCase("yes")); // Continue if the user says "yes"

        System.out.println("Thank you for using the system!");
    }
}


