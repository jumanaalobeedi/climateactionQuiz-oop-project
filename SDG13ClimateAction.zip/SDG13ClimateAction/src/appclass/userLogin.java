
package appclass;
import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class userLogin {
    public  void userChoose() {
        Scanner sc = new Scanner(System.in);
        String userType;
        do{
            System.out.println("Are you a public user or an admin user? (public/admin)");
            userType = sc.nextLine();
            if (!userType.equalsIgnoreCase("public") && !userType.equalsIgnoreCase("admin")) {
                System.out.println("Invalid input. Please enter 'public' or 'admin'.");
            }
        }while(!userType.equalsIgnoreCase("public") && !userType.equalsIgnoreCase("admin"));
        
        handleUserType(userType, sc);
    }
    
    private static void handleUserType(String userType, Scanner sc){
        if(userType.equalsIgnoreCase("public")){
            handlePublicUser(sc);
        }
        else if(userType.equalsIgnoreCase("admin")){
            handleAdminUser(sc);
        }
    }
    
    private static void handlePublicUser(Scanner sc){
        int choice;
        do{
            System.out.println("Choose an option: \n 1.Add new user. \n 2.Write existing username.");
            while(!sc.hasNextInt()){
                System.out.println("Invalid input. Please enter 1 or 2");
                sc.next();
            }
            choice = sc.nextInt();
            sc.nextLine();
        
            if(choice == 1){
            System.out.println("Enter a new username");
            String newUser = sc.nextLine();
            addPublicUser(newUser);
            }
           else if (choice == 2) {
                System.out.println("Enter your username:");
                String existingUser = sc.nextLine();
                if (checkPublicUserExists(existingUser)) {
                   publicUser pU = new publicUser();
                   pU.publicMenu();
                } else {
                    System.out.println("Username not found. Please try again or add yourself as a new user.");
                }
            } else {
                System.out.println("Invalid choice. Please select 1 or 2.");
            }
        } while (choice != 2);
        
    }
    
     private static boolean checkPublicUserExists(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader("src/sdg13climateaction/resources/LoginDetails.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals("public," + username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
        return false;
    }

    
    private static void handleAdminUser(Scanner sc){
        System.out.println("Enter your username please.");
        String adminUsername = sc.nextLine();
        System.out.println("Enter your password please.");
        String adminPassword = sc.nextLine();
        
        if(validateAdmin(adminUsername,adminPassword)){
            System.out.println("Login successful!");
            adminOptions(sc);
        }
        else{
            System.out.println("Invalid username or password!");
        }
    }
    
    private static void addPublicUser(String username){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter("src/sdg13climateaction/resources/LoginDetails.txt", true))){
            writer.write("public," + username);
            writer.newLine();
            System.out.println("User added successfully!");
            
        } catch (IOException ex) {
            Logger.getLogger(userLogin.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
     private static boolean validateAdmin(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader("src/sdg13climateaction/resources/LoginDetails.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("admin,")) {
                    String[] parts = line.split(",");
                    if (parts[1].equals(username) && parts[2].equals(password)) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
        return false;
    }
    
     private static void adminOptions(Scanner sc) {
        int choice;
        do {
            System.out.println("Choose an option: \n 1. Add new admin \n 2. Delete public user \n 3. Delete admin user \n 4.Edit real time alert system tracking \n 5.Edit Climate awareness blog page");
            while (!sc.hasNextInt()) {
                System.out.println("Invalid input. Please enter 1, 2, 3, 4 or 5.");
                sc.next();
            }
            choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {
                System.out.println("Enter new admin username:");
                String newAdmin = sc.nextLine();
                System.out.println("Enter new admin password:");
                String newPassword = sc.nextLine();
                addAdmin(newAdmin, newPassword);
            } else if (choice == 2) {
                System.out.println("Enter the public username to delete:");
                String userToDelete = sc.nextLine();
                deleteUser("public", userToDelete);
            } else if (choice == 3) {
                System.out.println("Enter the admin username to delete:");
                String userToDelete = sc.nextLine();
                deleteUser("admin", userToDelete);
            }else if (choice == 4){
                AlertWarningSys aWS = new AlertWarningSys();
                aWS.adminUserTasks();
            }else if (choice == 5){
                ClimateAwarenessBlog.BlogManager nm = new ClimateAwarenessBlog.BlogManager();
                nm.handleAdmin(new java.util.Scanner(System.in));
            } else {
                System.out.println("Invalid choice. Please select 1, 2, or 3.");
            }
        } while (choice < 1 || choice > 4);
    }
     
      private static void addAdmin(String username, String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/sdg13climateaction/resources/LoginDetails.txt", true))) {
            writer.write("admin," + username + "," + password);
            writer.newLine();
            System.out.println("Admin added successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
      
    private static void deleteUser(String userType, String username) {
        File inputFile = new File("src/sdg13climateaction/resources/LoginDetails.txt");
        File tempFile = new File("temp.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith(userType + "," + username)) {
                    writer.write(line);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

        if (tempFile.renameTo(inputFile)) {
            System.out.println("User deleted successfully!");
        } else {
            System.out.println("An error occurred while deleting the user.");
        }
    }
}

